
#define lint

#include "draw.c"
#include "drawlib.c"
#include "drawstr.c"
